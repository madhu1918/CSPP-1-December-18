b = 10
c = b > 9
c 