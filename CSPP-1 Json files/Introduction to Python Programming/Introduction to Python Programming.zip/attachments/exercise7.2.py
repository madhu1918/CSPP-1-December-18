a = a + 1.0
a 